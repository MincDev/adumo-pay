//
//  ViewController.swift
//  AdumoPaymentTest
//
//  Created by Christopher Smit on 2022/11/23.
//

import UIKit
import SwiftUI
import AdumoPay

struct MerchantApp {
    var name: String
    var uid: String

    init(name: String, uid: String) {
        self.name = name
        self.uid = uid
    }
}

class ViewController: UIViewController {
    let service = APService.shared
    let merchantUid: String = "9BA5008C-08EE-4286-A349-54AF91A621B0"
    let secret: String = "23adadc0-da2d-4dac-a128-4845a5d71293"
    var appUid: String!
    var initTransactionId: String?
    var apps: [MerchantApp]!

    @IBOutlet weak var txtAmount: UITextField!
    @IBOutlet weak var txtCardHolder: UITextField!
    @IBOutlet weak var txtCardNumber: UITextField!
    @IBOutlet weak var txtYearMonth: UITextField!
    @IBOutlet weak var btnReverse: UIButton!
    @IBOutlet weak var txtCvv: UITextField!
    @IBOutlet weak var pickerAppId: UIPickerView!

    override func viewDidLoad() {
        super.viewDidLoad()
        apps = [
            .init(name: "3D Secure App", uid: "23ADADC0-DA2D-4DAC-A128-4845A5D71293"),
            .init(name: "Non 3D Secure App", uid: "904A34AF-0CE9-42B1-9C98-B69E6329D154")
        ]
        appUid = apps[0].uid
        pickerAppId.delegate = self
    }

    @IBAction func onAuthenticateClick(_ sender: UIButton) {
        Task { @MainActor in
            let loadingAlert = showLoader(title: "Authenticating...")
            let result = await service.authenticate(withMerchantId: merchantUid,
                                                   andSecret: secret)

            switch result {
            case .success:
                loadingAlert.dismiss(animated: true) {
                    let alert = UIAlertController(
                        title: "Authenticated Successfully",
                        message: "Successfully authenticated. You may now initiate a transaction.",
                        preferredStyle: .alert
                    )
                    let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(actionOK)
                    self.present(alert, animated: true, completion: nil)
                }
            case .failure(let error):
                loadingAlert.dismiss(animated: true) {
                    let alert = UIAlertController(
                        title: "Authenticated Failed",
                        message: error.localizedDescription,
                        preferredStyle: .alert
                    )
                    let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(actionOK)
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    @IBAction func onCheckAuthDataClick(_ sender: UIButton) {
        if service.isAuthenticated() {
            let alert = UIAlertController(
                title: "Authenticated",
                message: "You are successfully authenticated. You can continue with a transaction.",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(
                title: "Not Authenticated",
                message: "You are not authenticated. Click on 'Authenticate' before attempting a transaction.",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func onCheckoutClick(_ sender: UIButton) {
        if service.isAuthenticated() {
            Task {
                let uuid = UUID().uuidString
                let result = await service.initiate(rootViewController: self, with: Transaction(
                    applicationUid: appUid,
                    merchantUid: merchantUid,
                    value: (txtAmount.text! as NSString).doubleValue,
                    merchantReference: uuid,
                    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36",
                    description: "Card Transaction",
                    originatingTransactionId: uuid,
                    cardNumber: txtCardNumber.text,
                    expiryMonth: 10,
                    expiryYear: 2024,
                    cardHolderFullName: txtCardHolder.text,
                    saveCardDetails: false,
                    authCallbackUrl: "https://test-gateway.wirecard.co.za/channel-virtual/api/v1/card/callback"
                ))

                switch result {
                case .success(let data):
                    let alert = UIAlertController(
                        title: "3D Secure Authentication Passed",
                        message: "The 3D Secure Authentication was successful. Transaction can be authorised.",
                        preferredStyle: .alert
                    )
                    let actionOK = UIAlertAction(title: "Authorise Payment", style: .default) { _ in
                        Task {
                            self.initTransactionId = data!.uidTransactionIndex
                            await self.authorisePayment(transactionId: data!.uidTransactionIndex, cvvRequired: data!.cvvRequired)
                        }
                    }
                    alert.addAction(actionOK)
                    self.present(alert, animated: true, completion: nil)
                case .failure(let error):
                    let alert = UIAlertController(
                        title: "3D Secure Authentication Failed",
                        message: error.localizedDescription,
                        preferredStyle: .alert
                    )
                    let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(actionOK)
                    self.present(alert, animated: true, completion: nil)
                case .cancelled:
                    let alert = UIAlertController(
                        title: "3D Secure Authentication Cancelled",
                        message: "The 3D Secure Authentication was cancelled and payment is not possible. Please try again.",
                        preferredStyle: .alert
                    )
                    let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(actionOK)
                    self.present(alert, animated: true, completion: nil)

                    debugPrint("AEClient no longer authenticated.")
                }
            }
        } else {
            let alert = UIAlertController(
                title: "Not Authenticated",
                message: "A transaction can't be initiated. Did you forget to authenticate?",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func onReverseClick(_ sender: UIButton) {
        guard let transactionId = initTransactionId else {
            let alert = UIAlertController(
                title: "No Authorised Transaction",
                message: "There is no authorised transaction to reverse.",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
            return
        }

        Task {
            let result = await service.reverse(transactionId: transactionId)

            switch result {
            case .success(let data):
                let alert = UIAlertController(
                    title: "Transaction Reversed",
                    message: "The transaction for R \(data!.reversedAmount) was successfully reversed.",
                    preferredStyle: .alert
                )
                let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(actionOK)
                self.present(alert, animated: true, completion: nil)
            case .failure(let error):
                let alert = UIAlertController(
                    title: "Could Not Reverse",
                    message: "The transaction could not be reversed. \(error.localizedDescription)",
                    preferredStyle: .alert
                )
                let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(actionOK)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

    @IBAction func onSettleClick(_ sender: UIButton) {
        guard let transactionId = initTransactionId else {
            let alert = UIAlertController(
                title: "No Authorised Transaction",
                message: "There is no authorised transaction to reverse.",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
            return
        }

        Task {
            let result = await service.settle(transactionId: transactionId, amount: (txtAmount.text! as NSString).doubleValue)

            switch result {
            case .success(let data):
                let alert = UIAlertController(
                    title: "Transaction Settled",
                    message: "The transaction for R \(data!.settledAmount) was successfully settled.",
                    preferredStyle: .alert
                )
                let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(actionOK)
                self.present(alert, animated: true, completion: nil)
            case .failure(let error):
                let alert = UIAlertController(
                    title: "Transaction Not Settled",
                    message: "The transaction could not be settled settled. \(error.localizedDescription)",
                    preferredStyle: .alert
                )
                let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(actionOK)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func onRefundClick(_ sender: UIButton) {
        guard let transactionId = initTransactionId else {
            let alert = UIAlertController(
                title: "No Authorised Transaction",
                message: "There is no authorised transaction to reverse.",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
            return
        }

        Task {
            let result = await service.refund(transactionId: transactionId, amount: (txtAmount.text! as NSString).doubleValue)

            switch result {
            case .success(let data):
                let alert = UIAlertController(
                    title: "Transaction Refunded",
                    message: "The transaction was successfully refunded.",
                    preferredStyle: .alert
                )
                let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(actionOK)
                self.present(alert, animated: true, completion: nil)
            case .failure(let error):
                let alert = UIAlertController(
                    title: "Transaction Not Refunded",
                    message: "The transaction could not be refunded. \(error.localizedDescription)",
                    preferredStyle: .alert
                )
                let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(actionOK)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

    private func showLoader(title: String) -> UIAlertController {
        let loadingAlert = UIAlertController(title: nil, message: title, preferredStyle: .alert)
        loadingAlert.view.tintColor = .black
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.startAnimating()
        loadingAlert.view.addSubview(loadingIndicator)
        self.present(loadingAlert, animated: true)
        return loadingAlert
    }

    func authorisePayment(transactionId: String, cvvRequired: Bool) async {
        let result = await service.authorise(transactionId: transactionId,
                                             amount: (txtAmount.text! as NSString).doubleValue,
                                             cvv: cvvRequired ? Int(txtCvv.text!) : nil)

        switch result {
        case .success(let data):
            let alert = UIAlertController(
                title: "Successfully Authorised",
                message: "The amount of R \(data!.authorisedAmount) was successfully authorised.",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        case .failure(let error):
            let alert = UIAlertController(
                title: "Not Authorised",
                message: "The payment could not be authorised. \(error.localizedDescription)",
                preferredStyle: .alert
            )
            let actionOK = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
    }
}

extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.apps.count
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.appUid = apps[row].uid
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.apps[row].name
    }
}
